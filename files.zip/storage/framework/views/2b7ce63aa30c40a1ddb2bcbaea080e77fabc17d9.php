<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Response</title>
</head>
<body>
    <pre>
    <?php echo e($response); ?>

    </pre>
</body>
</html><?php /**PATH /Users/aljon.cruz/Documents/personal/stripe-studytube/resources/views/response.blade.php ENDPATH**/ ?>